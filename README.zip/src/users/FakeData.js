export const userData = [
  {
    id: 1,
    name: "Dronzer",
    email: "dronzer@gmail.com",
    mobile: "7894561230",
    status: 1,
  },
  {
    id: 2,
    name: "Naruto",
    email: "naruto@gmail.com",
    mobile: "7855561230",
    status: 0,
  },
  {
    id: 3,
    name: "Shinchan",
    email: "shinchan@gmail.com",
    mobile: "7898881230",
    status: 0,
  },
  {
    id: 4,
    name: "Gojo",
    email: "gojo@gmail.com",
    mobile: "7894569999",
    status: 1,
  },
];
