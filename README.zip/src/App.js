import BasicTabs from "./users/UserTask";

function App() {
  return (
    <>
      <BasicTabs />
    </>
  );
}

export default App;
